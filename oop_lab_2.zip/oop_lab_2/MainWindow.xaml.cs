﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media; // Для Brush, Colors
using System.Windows.Shapes; // Для Rectangle (UI element)
using Lab2_Rectangles; // Підключаємо простір імен, де знаходиться наш клас Rectangle

namespace Lab2_Rectangles
{
    /// <summary>
    /// Логіка взаємодії для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        // Оголошуємо екземпляри класу Rectangle, які будемо використовувати
        private Rectangle rect1Instance;
        private Rectangle rect2Instance;

        // Конструктор головного вікна
        public MainWindow()
        {
            InitializeComponent();
            // Ініціалізуємо прямокутники з початковими значеннями з TextBox-ів,
            // щоб вони були доступні для операцій одразу після запуску.
            CreateRectanglesFromUI();
            UpdateCurrentRectanglesDisplay(); // Оновлюємо відображення одразу
        }

        /// <summary>
        /// Створює або оновлює екземпляри прямокутників з введених значень UI.
        /// Обробляє можливі помилки парсингу або некоректні розміри.
        /// </summary>
        private void CreateRectanglesFromUI()
        {
            // Створення/оновлення Rectangle 1
            try
            {
                double x1 = double.Parse(txtRect1X.Text);
                double y1 = double.Parse(txtRect1Y.Text);
                double width1 = double.Parse(txtRect1Width.Text);
                double height1 = double.Parse(txtRect1Height.Text);
                rect1Instance = new Rectangle(x1, y1, width1, height1);
                lblRect1Status.Text = "Прямокутник 1 створено/оновлено!";
                lblRect1Status.Foreground = Brushes.Green;
            }
            catch (FormatException)
            {
                lblRect1Status.Text = "Помилка: Некоректний формат числа для Р1!";
                lblRect1Status.Foreground = Brushes.Red;
                rect1Instance = null; // Позначаємо як недійсний
            }
            catch (ArgumentException ex)
            {
                lblRect1Status.Text = "Помилка: " + ex.Message;
                lblRect1Status.Foreground = Brushes.Red;
                rect1Instance = null; // Позначаємо як недійсний
            }

            // Створення/оновлення Rectangle 2
            try
            {
                double x2 = double.Parse(txtRect2X.Text);
                double y2 = double.Parse(txtRect2Y.Text);
                double width2 = double.Parse(txtRect2Width.Text);
                double height2 = double.Parse(txtRect2Height.Text);
                rect2Instance = new Rectangle(x2, y2, width2, height2);
                lblRect2Status.Text = "Прямокутник 2 створено/оновлено!";
                lblRect2Status.Foreground = Brushes.Green;
            }
            catch (FormatException)
            {
                lblRect2Status.Text = "Помилка: Некоректний формат числа для Р2!";
                lblRect2Status.Foreground = Brushes.Red;
                rect2Instance = null; // Позначаємо як недійсний
            }
            catch (ArgumentException ex)
            {
                lblRect2Status.Text = "Помилка: " + ex.Message;
                lblRect2Status.Foreground = Brushes.Red;
                rect2Instance = null; // Позначаємо як недійсний
            }

            UpdateCurrentRectanglesDisplay();
            DrawRectanglesOnCanvas();
        }

        /// <summary>
        /// Обробник натискання кнопок "Створити/Оновити Р1/Р2".
        /// </summary>
        private void CreateRectangles_Click(object sender, RoutedEventArgs e)
        {
            CreateRectanglesFromUI();
        }

        /// <summary>
        /// Оновлює текстові блоки, що відображають поточний стан прямокутників.
        /// </summary>
        private void UpdateCurrentRectanglesDisplay()
        {
            lblCurrentRect1.Text = rect1Instance != null ? $"Прямокутник 1: {rect1Instance.ToString()}" : "Прямокутник 1: Не створено";
            lblCurrentRect2.Text = rect2Instance != null ? $"Прямокутник 2: {rect2Instance.ToString()}" : "Прямокутник 2: Не створено";
        }

        /// <summary>
        /// Переміщує прямокутник 1 на фіксовані deltaX та deltaY.
        /// </summary>
        private void MoveRect1_Click(object sender, RoutedEventArgs e)
        {
            if (rect1Instance != null)
            {
                rect1Instance.Move(10, 5); // Переміщуємо на 10 по X, на 5 по Y
                lblRect1Status.Text = "Прямокутник 1 переміщено!";
                lblRect1Status.Foreground = Brushes.Green;
                UpdateCurrentRectanglesDisplay();
                DrawRectanglesOnCanvas();
            }
            else
            {
                lblRect1Status.Text = "Створіть Прямокутник 1 спочатку!";
                lblRect1Status.Foreground = Brushes.OrangeRed;
            }
        }

        /// <summary>
        /// Переміщує прямокутник 2 на фіксовані deltaX та deltaY.
        /// </summary>
        private void MoveRect2_Click(object sender, RoutedEventArgs e)
        {
            if (rect2Instance != null)
            {
                rect2Instance.Move(-5, 15); // Переміщуємо на -5 по X, на 15 по Y
                lblRect2Status.Text = "Прямокутник 2 переміщено!";
                lblRect2Status.Foreground = Brushes.Green;
                UpdateCurrentRectanglesDisplay();
                DrawRectanglesOnCanvas();
            }
            else
            {
                lblRect2Status.Text = "Створіть Прямокутник 2 спочатку!";
                lblRect2Status.Foreground = Brushes.OrangeRed;
            }
        }

        /// <summary>
        /// Змінює розмір прямокутника 1 на фіксовані нові розміри.
        /// </summary>
        private void ResizeRect1_Click(object sender, RoutedEventArgs e)
        {
            if (rect1Instance != null)
            {
                try
                {
                    rect1Instance.Resize(120, 60); // Змінюємо розмір
                    lblRect1Status.Text = "Прямокутник 1 змінено розмір!";
                    lblRect1Status.Foreground = Brushes.Green;
                    UpdateCurrentRectanglesDisplay();
                    DrawRectanglesOnCanvas();
                }
                catch (ArgumentException ex)
                {
                    lblRect1Status.Text = "Помилка при зміні розміру Р1: " + ex.Message;
                    lblRect1Status.Foreground = Brushes.Red;
                }
            }
            else
            {
                lblRect1Status.Text = "Створіть Прямокутник 1 спочатку!";
                lblRect1Status.Foreground = Brushes.OrangeRed;
            }
        }

        /// <summary>
        /// Змінює розмір прямокутника 2 на фіксовані нові розміри.
        /// </summary>
        private void ResizeRect2_Click(object sender, RoutedEventArgs e)
        {
            if (rect2Instance != null)
            {
                try
                {
                    rect2Instance.Resize(90, 130); // Змінюємо розмір
                    lblRect2Status.Text = "Прямокутник 2 змінено розмір!";
                    lblRect2Status.Foreground = Brushes.Green;
                    UpdateCurrentRectanglesDisplay();
                    DrawRectanglesOnCanvas();
                }
                catch (ArgumentException ex)
                {
                    lblRect2Status.Text = "Помилка при зміні розміру Р2: " + ex.Message;
                    lblRect2Status.Foreground = Brushes.Red;
                }
            }
            else
            {
                lblRect2Status.Text = "Створіть Прямокутник 2 спочатку!";
                lblRect2Status.Foreground = Brushes.OrangeRed;
            }
        }

        /// <summary>
        /// Обчислює об'єднання двох прямокутників та виводить результат.
        /// </summary>
        private void UnionRectangles_Click(object sender, RoutedEventArgs e)
        {
            if (rect1Instance != null && rect2Instance != null)
            {
                Rectangle unionRect = Rectangle.Union(rect1Instance, rect2Instance);
                lblUnionResult.Text = $"Об'єднання: {unionRect.ToString()}";
                lblUnionResult.Foreground = Brushes.DarkGreen;
                DrawRectanglesOnCanvas(unionRect, Brushes.LightGray); // Відображаємо об'єднання
            }
            else
            {
                lblUnionResult.Text = "Обидва прямокутники мають бути створені для об'єднання.";
                lblUnionResult.Foreground = Brushes.OrangeRed;
            }
        }

        /// <summary>
        /// Обчислює перетинання двох прямокутників та виводить результат.
        /// </summary>
        private void IntersectRectangles_Click(object sender, RoutedEventArgs e)
        {
            if (rect1Instance != null && rect2Instance != null)
            {
                Rectangle intersectRect = Rectangle.Intersect(rect1Instance, rect2Instance);
                if (intersectRect != null)
                {
                    lblIntersectResult.Text = $"Перетинання: {intersectRect.ToString()}";
                    lblIntersectResult.Foreground = Brushes.DarkRed;
                    DrawRectanglesOnCanvas(intersectRect, Brushes.LightCoral); // Відображаємо перетинання
                }
                else
                {
                    lblIntersectResult.Text = "Прямокутники не перетинаються.";
                    lblIntersectResult.Foreground = Brushes.OrangeRed;
                }
            }
            else
            {
                lblIntersectResult.Text = "Обидва прямокутники мають бути створені для перетинання.";
                lblIntersectResult.Foreground = Brushes.OrangeRed;
            }
        }

        /// <summary>
        /// Візуалізує прямокутники на Canvas.
        /// Масштабує координати для кращого відображення.
        /// </summary>
        /// <param name="additionalRect">Додатковий прямокутник для відображення (наприклад, об'єднання/перетинання).</param>
        /// <param name="additionalColor">Колір додаткового прямокутника.</param>
        private void DrawRectanglesOnCanvas(Rectangle additionalRect = null, Brush additionalColor = null)
        {
            drawingCanvas.Children.Clear(); // Очищаємо Canvas перед перемальовкою

            // Коефіцієнт масштабування для відображення
            // Припускаємо, що 100 одиниць = 150px
            double scaleFactor = 1.5;

            // Функція для створення візуального прямокутника WPF
            System.Windows.Shapes.Rectangle CreateWpfRectangle(Rectangle rect, Brush fill, Brush stroke, double strokeThickness)
            {
                if (rect == null) return null;

                System.Windows.Shapes.Rectangle wpfRect = new System.Windows.Shapes.Rectangle
                {
                    Width = rect.Width * scaleFactor,
                    Height = rect.Height * scaleFactor,
                    Fill = fill,
                    Stroke = stroke,
                    StrokeThickness = strokeThickness
                };
                Canvas.SetLeft(wpfRect, rect.X * scaleFactor);
                Canvas.SetTop(wpfRect, rect.Y * scaleFactor);
                return wpfRect;
            }

            // Малюємо додатковий прямокутник (об'єднання/перетинання) першим, щоб він був під основними
            if (additionalRect != null && additionalColor != null)
            {
                System.Windows.Shapes.Rectangle addRectWPF = CreateWpfRectangle(additionalRect, additionalColor, Brushes.Gray, 1);
                if (addRectWPF != null)
                {
                    drawingCanvas.Children.Add(addRectWPF);
                }
            }

            // Малюємо Rectangle 1
            if (rect1Instance != null)
            {
                System.Windows.Shapes.Rectangle rect1WPF = CreateWpfRectangle(rect1Instance, Brushes.LightBlue, Brushes.Blue, 2);
                if (rect1WPF != null)
                {
                    drawingCanvas.Children.Add(rect1WPF);
                }
            }

            // Малюємо Rectangle 2
            if (rect2Instance != null)
            {
                System.Windows.Shapes.Rectangle rect2WPF = CreateWpfRectangle(rect2Instance, Brushes.LightCoral, Brushes.Red, 2);
                if (rect2WPF != null)
                {
                    drawingCanvas.Children.Add(rect2WPF);
                }
            }
        }
    }
}
