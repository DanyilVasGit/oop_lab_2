﻿using System;

// Важливо: переконайтеся, що цей простір імен відповідає простору імен вашого проекту.
// Якщо ваш проект називається "Lab2_Rectangles", то залиште так.
namespace Lab2_Rectangles
{
    /// <summary>
    /// Клас, що представляє прямокутник зі сторонами, паралельними осям координат.
    /// Прямокутник визначається координатами лівого верхнього кута (X, Y), шириною (Width) та висотою (Height).
    /// </summary>
    public class Rectangle
    {
        // Властивості прямокутника
        public double X { get; private set; } // Координата X лівого верхнього кута
        public double Y { get; private set; } // Координата Y лівого верхнього кута
        public double Width { get; private set; } // Ширина прямокутника
        public double Height { get; private set; } // Висота прямокутника

        /// <summary>
        /// Конструктор для створення нового екземпляра класу Rectangle.
        /// </summary>
        /// <param name="x">Координата X лівого верхнього кута.</param>
        /// <param name="y">Координата Y лівого верхнього кута.</param>
        /// <param name="width">Ширина прямокутника (має бути невід'ємною).</param>
        /// <param name="height">Висота прямокутника (має бути невід'ємною).</param>
        /// <exception cref="ArgumentException">Викидається, якщо ширина або висота від'ємні.</exception>
        public Rectangle(double x, double y, double width, double height)
        {
            if (width < 0 || height < 0)
            {
                throw new ArgumentException("Ширина та висота прямокутника не можуть бути від'ємними.");
            }

            X = x;
            Y = y;
            Width = width;
            Height = height;
        }

        /// <summary>
        /// Переміщує прямокутник на задані відстані по осях X та Y.
        /// </summary>
        /// <param name="deltaX">Відстань для переміщення по осі X.</param>
        /// <param name="deltaY">Відстань для переміщення по осі Y.</param>
        public void Move(double deltaX, double deltaY)
        {
            X += deltaX;
            Y += deltaY;
        }

        /// <summary>
        /// Змінює розміри прямокутника.
        /// Нова ширина та висота повинні бути невід'ємними.
        /// </summary>
        /// <param name="newWidth">Нова ширина прямокутника.</param>
        /// <param name="newHeight">Нова висота прямокутника.</param>
        /// <exception cref="ArgumentException">Викидається, якщо нова ширина або висота від'ємні.</exception>
        public void Resize(double newWidth, double newHeight)
        {
            if (newWidth < 0 || newHeight < 0)
            {
                throw new ArgumentException("Нова ширина та висота прямокутника не можуть бути від'ємними.");
            }

            Width = newWidth;
            Height = newHeight;
        }

        /// <summary>
        /// Повертає прямокутник, який є найменшим об'єднуючим для двох заданих прямокутників.
        /// </summary>
        /// <param name="rect1">Перший прямокутник.</param>
        /// <param name="rect2">Другий прямокутник.</param>
        /// <returns>Новий об'єкт Rectangle, що представляє найменший об'єднуючий прямокутник.</returns>
        public static Rectangle Union(Rectangle rect1, Rectangle rect2)
        {
            double minX = Math.Min(rect1.X, rect2.X);
            double minY = Math.Min(rect1.Y, rect2.Y);

            double maxX1 = rect1.X + rect1.Width;
            double maxY1 = rect1.Y + rect1.Height;
            double maxX2 = rect2.X + rect2.Width;
            double maxY2 = rect2.Y + rect2.Height;

            double maxX = Math.Max(maxX1, maxX2);
            double maxY = Math.Max(maxY1, maxY2);

            return new Rectangle(minX, minY, maxX - minX, maxY - minY);
        }

        /// <summary>
        /// Повертає прямокутник, який є спільною частиною (перетинанням) двох заданих прямокутників.
        /// Якщо прямокутники не перетинаються, повертається null.
        /// </summary>
        /// <param name="rect1">Перший прямокутник.</param>
        /// <param name="rect2">Другий прямокутник.</param>
        /// <returns>Новий об'єкт Rectangle, що представляє перетинання, або null, якщо перетинання відсутнє.</returns>
        public static Rectangle Intersect(Rectangle rect1, Rectangle rect2)
        {
            double x1 = Math.Max(rect1.X, rect2.X);
            double y1 = Math.Max(rect1.Y, rect2.Y);

            double x2 = Math.Min(rect1.X + rect1.Width, rect2.X + rect2.Width);
            double y2 = Math.Min(rect1.Y + rect1.Height, rect2.Y + rect2.Height);

            // Перевіряємо, чи є перетинання (x1 < x2 та y1 < y2)
            if (x1 < x2 && y1 < y2)
            {
                return new Rectangle(x1, y1, x2 - x1, y2 - y1);
            }
            else
            {
                return null; // Прямокутники не перетинаються
            }
        }

        /// <summary>
        /// Перевизначення методу ToString() для зручного відображення інформації про прямокутник.
        /// </summary>
        /// <returns>Рядок, що описує прямокутник.</returns>
        public override string ToString()
        {
            return $"Прямокутник: X={X}, Y={Y}, Ширина={Width}, Висота={Height}";
        }
    }
}